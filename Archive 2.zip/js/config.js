/**
 * ═══════════════════════════════════════════════════════════════
 *   Wedding Invitation — Central Configuration File
 * ═══════════════════════════════════════════════════════════════
 *  Populated with the exact real details from the invitation card!
 *  You can edit any text, time, or phone number anytime in this file.
 * ═══════════════════════════════════════════════════════════════
 */

const WEDDING_CONFIG = {

  /* ───── 💑 COUPLE ───── */
  bride: {
    firstName:    "Yashodya",
    fullName:     "Yashodya Wickramaratne",
    parents:      "Mr. and Mrs. Wickramaratne",
    phone:        "0717172900",
    phoneDisplay: "071 717 2900",
    whatsapp:     "94717172900",
    instagram:    "",
    bio:          "The bride who brings grace, warmth, and endless joy to every moment."
  },

  groom: {
    firstName:    "Vihanga",
    fullName:     "Vihanga Aluthge",
    parents:      "Mr. and Mrs. Aluthge",
    phone:        "0779140659",
    phoneDisplay: "077 914 0659",
    whatsapp:     "94779140659",
    instagram:    "",
    bio:          "The groom who found his forever home in her smile."
  },

  /* ───── 📅 EVENT ───── */
  event: {
    dateISO:          "2026-12-14T10:00:00+05:30",
    dayOfWeek:        "Monday",
    dateFormatted:    "14th December 2026",
    startTime:        "10:00 AM",
    poruwaTime:       "10:50 AM",
    rsvpDeadline:     "30th November 2026",
    calendarSummary:  "Wedding of Yashodya & Vihanga",
    calendarDescription: "We warmly invite you to celebrate the wedding of Yashodya & Vihanga at Deandra Bolgoda. Poruwa ceremony at 10:50 AM.",
  },

  /* ───── 📍 VENUE ───── */
  venue: {
    name:               "Deandra Bolgoda",
    subName:            "Bolgoda Lake, Sri Lanka",
    fullAddress:        "Deandra Bolgoda, Bolgoda Lake, Piliyandala / Moratuwa, Sri Lanka",
    googleMapsSearchUrl:"https://www.google.com/maps/search/?api=1&query=Deandra+Bolgoda",
    googleMapsEmbedUrl: "https://maps.google.com/maps?q=Deandra%20Bolgoda&t=&z=15&ie=UTF8&iwloc=&output=embed",
    dressCode:          "Formal / Traditional Sri Lankan / Elegant Pastel & Gold",
    parkingInfo:        "Ample on-site parking available with valet assistance."
  },

  /* ───── 🗓️ ORDER OF EVENTS ───── */
  schedule: [
    {
      time:  "10:00 AM",
      title: "Welcome & Guest Arrival",
      desc:  "Gathering of family and friends with welcome refreshments by scenic Bolgoda Lake.",
      icon:  "fa-glass-cheers"
    },
    {
      time:  "10:50 AM",
      title: "Traditional Poruwa Ceremony",
      desc:  "The sacred traditional Sri Lankan rituals and tying of the wedding knot at the auspicious time.",
      icon:  "fa-ring"
    },
    {
      time:  "11:45 AM",
      title: "Champagne Toast & Cake Cutting",
      desc:  "Celebratory toast, lighting of the traditional brass oil lamp, and cake cutting.",
      icon:  "fa-cake-candles"
    },
    {
      time:  "12:30 PM",
      title: "Wedding Lunch & Banquet",
      desc:  "A delectable feast and joyous celebration with live music.",
      icon:  "fa-utensils"
    },
    {
      time:  "02:00 PM",
      title: "Music, Celebration & Photos",
      desc:  "Music, dancing, laughter, and family photographs.",
      icon:  "fa-camera"
    },
    {
      time:  "03:30 PM",
      title: "Going Away & Farewell",
      desc:  "Warm blessings as the newly wedded couple embarks on their forever journey.",
      icon:  "fa-car-side"
    }
  ],

  /* ───── 🖼️ GALLERY ───── */
  gallery: [
    {
      url:      "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=800&q=80",
      caption:  "Together is our favorite place to be",
      category: "Engagement"
    },
    {
      url:      "https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=800&q=80",
      caption:  "Hand in hand towards forever",
      category: "Our Journey"
    },
    {
      url:      "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=800&q=80",
      caption:  "Every love story is beautiful, but ours is our favorite",
      category: "Moments"
    },
    {
      url:      "https://images.unsplash.com/photo-1606800052052-a08af7148866?auto=format&fit=crop&w=800&q=80",
      caption:  "Two hearts, one lifelong promise",
      category: "Love"
    }
  ],

  /* ───── 💌 INVITATION CARD ───── */
  invitationCardImage: "assets/images/invitation-card.jpg",

  /* ───── 🎵 BACKGROUND MUSIC ───── */
  music: {
    enabled:          true,
    audioSrc:         "assets/audio/wedding-bgm.mp3",
    trackTitle:       "Romantic Wedding Melody"
  },

  /* ───── 🔗 WEBSITE / SOCIAL ───── */
  website: {
    url:      "savethedate.lk/yashodya&vihanga",
    hashtag:  "#YashodyaAndVihanga2026"
  }

};

// Make config globally available
window.WEDDING_CONFIG = WEDDING_CONFIG;
