/**
 * ══════════════════════════════════════════════════════
 *   Yomali & Harindu Wedding — Main Application
 *   Gold Particle Intro · Countdown · RSVP · Music
 * ══════════════════════════════════════════════════════
 */

document.addEventListener("DOMContentLoaded", () => {
  const cfg = window.WEDDING_CONFIG;
  if (!cfg) return;

  // ⚡ Intro screen & music must run first — never blocked by other errors
  try { setupIntro(cfg);       } catch(e) { console.warn("Intro error:", e); }
  try { setupMusic(cfg.music); } catch(e) { console.warn("Music error:", e); }

  // Content sections — isolated so placeholder data can't crash the page
  try { hydrateContent(cfg);         } catch(e) { console.warn("Hydrate:", e); }
  try { initCountdown(cfg.event.dateISO); } catch(e) { console.warn("Countdown:", e); }
  try { setupCalendar(cfg);          } catch(e) { console.warn("Calendar:", e); }
  try { renderTimeline(cfg.schedule);} catch(e) { console.warn("Timeline:", e); }
  try { renderGallery(cfg.gallery);  } catch(e) { console.warn("Gallery:", e); }
  try { setupCard(cfg.invitationCardImage); } catch(e) { console.warn("Card:", e); }
  try { setupRSVP(cfg);              } catch(e) { console.warn("RSVP:", e); }
  try { setupBlessings();            } catch(e) { console.warn("Blessings:", e); }
});

/* ─────────────────────────────────────────
   Helpers
───────────────────────────────────────── */
const $  = id => document.getElementById(id);
const tx = (id, val) => { const el = $(id); if (el) el.textContent = val; };
const esc = s => !s ? "" : s.replace(/[&<>"']/g, m =>
  ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const isPlaceholder = v => !v || /\[|\]|XXXXXXX|XX:XX/.test(v);

function setField(id, val) {
  const el = $(id); if (!el) return;
  el.textContent = val;
  if (isPlaceholder(val)) {
    el.classList.add("ph");
    el.title = "⚠️ Fill this in → js/config.js";
  } else {
    el.classList.remove("ph");
  }
}

/* ─────────────────────────────────────────
   1. CINEMATIC INTRO + GOLD PARTICLE FIELD
───────────────────────────────────────── */
function setupIntro(cfg) {
  const screen  = $("introScreen");
  const enterBtn = $("enterBtn");
  const reopenBtn = $("reopenBtn");
  const guestTag  = $("introGuestTag");
  const heroGuest = $("heroGuestName");
  const heroBadge = $("heroGuestBadge");
  const rsvpNameEl = $("rsvpName");

  // Extract guest name from URL (?guest=Name, ?to=Name, ?name=Name)
  const params = new URLSearchParams(location.search);
  const raw = params.get("guest") || params.get("to") || params.get("name") || "Dear Guest";
  const guestName = decodeURIComponent(raw).trim();

  // Personalise guest displays
  if (guestTag) {
    guestTag.innerHTML = `Warmly Welcoming <span class="guest-name">${esc(guestName)}</span>`;
  }
  if (heroGuest) heroGuest.textContent = guestName;
  if (heroBadge) heroBadge.innerHTML =
    `Warmly Welcoming <strong>${esc(guestName)}</strong>`;
  if (rsvpNameEl && guestName !== "Dear Guest") rsvpNameEl.value = guestName;

  // Start gold particle canvas animation
  startParticles();

  let entered = false;

  function enter() {
    if (entered) return;
    entered = true;

    // Gold sparkle burst
    goldBurst();

    // Start music
    if (window._music) window._music.start();

    // Fade out intro screen
    screen.classList.add("exit");
    document.body.classList.remove("locked");
  }

  if (enterBtn)  enterBtn.addEventListener("click",  enter);
  if (screen)    screen.addEventListener("click",    enter); // tap anywhere

  if (reopenBtn) {
    reopenBtn.addEventListener("click", () => {
      entered = false;
      screen.classList.remove("exit");
      document.body.classList.add("locked");
    });
  }

  // ?skip=1 bypass
  if (params.get("skip") === "1") {
    screen.classList.add("exit");
    document.body.classList.remove("locked");
  } else {
    document.body.classList.add("locked");
  }
}

/* ── Gold Particle Canvas ── */
function startParticles() {
  const canvas = $("particleCanvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");

  function resize() {
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener("resize", resize);

  const NUM = 90;
  const particles = [];

  // Particle palette: rich 24k gold, amber, and bronze specks visible on light marble
  const COLORS = [
    "rgba(190,145,45,",
    "rgba(212,175,55,",
    "rgba(175,130,30,",
    "rgba(225,180,65,",
    "rgba(160,115,25,",
  ];

  for (let i = 0; i < NUM; i++) {
    particles.push(makeParticle());
  }

  function makeParticle(fromBottom = false) {
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];
    return {
      x:     Math.random() * (canvas.width  || window.innerWidth),
      y:     fromBottom
               ? (canvas.height || window.innerHeight) + Math.random() * 40
               : Math.random() * (canvas.height || window.innerHeight),
      r:     0.7 + Math.random() * 2.4,
      speed: 0.25 + Math.random() * 0.55,
      drift: (Math.random() - 0.5) * 0.4,
      alpha: 0.30 + Math.random() * 0.55,
      alphaDir: Math.random() > 0.5 ? 1 : -1,
      alphaDelta: 0.004 + Math.random() * 0.008,
      color,
    };
  }

  let raf;
  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    for (let i = 0; i < particles.length; i++) {
      const p = particles[i];
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `${p.color}${p.alpha.toFixed(2)})`;
      ctx.fill();

      // Subtle radial glow for larger particles
      if (p.r > 1.5) {
        const grd = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 3);
        grd.addColorStop(0, `${p.color}${(p.alpha * 0.35).toFixed(2)})`);
        grd.addColorStop(1, `${p.color}0)`);
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r * 3, 0, Math.PI * 2);
        ctx.fillStyle = grd;
        ctx.fill();
      }

      // Move upward with gentle drift
      p.y -= p.speed;
      p.x += p.drift;

      // Twinkle alpha
      p.alpha += p.alphaDelta * p.alphaDir;
      if (p.alpha > 0.85 || p.alpha < 0.10) {
        p.alphaDir *= -1;
      }

      // Recycle off-screen particles
      if (p.y < -10) {
        particles[i] = makeParticle(true);
      }
    }

    raf = requestAnimationFrame(draw);
  }

  draw();

  // Stop canvas when intro exits
  const screen = $("introScreen");
  if (screen) {
    const obs = new MutationObserver(() => {
      if (screen.classList.contains("exit")) {
        cancelAnimationFrame(raf);
        obs.disconnect();
      }
    });
    obs.observe(screen, { attributes: true, attributeFilter: ["class"] });
  }
}

/* ── Gold sparkle burst on enter ── */
function goldBurst() {
  const shades = ["#c8a951","#e8c97e","#f5e4b0","#fdf0c0","#b8920e","#fff8d8"];
  for (let i = 0; i < 35; i++) {
    const el = document.createElement("div");
    el.className = "sparkle";
    const size = 8 + Math.random() * 14;
    el.style.cssText = `
      width:${size}px; height:${size * 1.5}px;
      background:${shades[Math.floor(Math.random() * shades.length)]};
      left:${44 + Math.random() * 12}vw;
      top:${44 + Math.random() * 12}vh;
      animation-duration:${1.2 + Math.random() * 1.6}s;
      transform: scale(${0.4 + Math.random()}) rotate(${Math.random() * 360}deg);
      border-radius: 50% 0 50% 50%;
    `;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 2800);
  }
}

/* ─────────────────────────────────────────
   2. HYDRATE ALL TEXT FROM CONFIG
───────────────────────────────────────── */
function hydrateContent(cfg) {
  tx("heroBrideName",    cfg.bride.firstName);
  tx("heroGroomName",    cfg.groom.firstName);
  tx("introBrideName",   cfg.bride.firstName);
  tx("introGroomName",   cfg.groom.firstName);
  tx("brideFirstName",   cfg.bride.firstName);
  tx("groomFirstName",   cfg.groom.firstName);
  tx("footerBrideName",  cfg.bride.firstName);
  tx("footerGroomName",  cfg.groom.firstName);

  setField("heroBrideParents", cfg.bride.parents);
  setField("heroGroomParents", cfg.groom.parents);
  setField("eventDayOfWeek",   cfg.event.dayOfWeek);
  setField("eventDate",        cfg.event.dateFormatted);
  setField("eventStartTime",   cfg.event.startTime + " Onwards");
  setField("eventPoruwa",      "(Poruwa Ceremony " + cfg.event.poruwaTime + ")");
  setField("venueName",        cfg.venue.name);
  setField("venueSubName",     cfg.venue.subName);
  setField("venueNameDetail",  cfg.venue.name);
  setField("venueAddress",     cfg.venue.fullAddress);
  setField("venueDressCode",   cfg.venue.dressCode);
  setField("venueParking",     cfg.venue.parkingInfo);
  setField("venueOpenTime",    cfg.event.startTime);
  setField("rsvpDeadline",     cfg.event.rsvpDeadline);
  setField("heroRsvpDate",     cfg.event.rsvpDeadline);
  setField("footerHashtag",    cfg.website.hashtag);
  setField("footerDate",       cfg.event.dateFormatted);
  setField("footerVenue",      cfg.venue.name);

  // Phone numbers
  setField("bridePhoneDisplay", cfg.bride.phoneDisplay);
  setField("groomPhoneDisplay", cfg.groom.phoneDisplay);

  // Map
  const mapIframe = $("venueMapIframe");
  const mapPh     = $("mapPlaceholder");
  if (mapIframe && cfg.venue.googleMapsEmbedUrl) {
    mapIframe.src = cfg.venue.googleMapsEmbedUrl;
    mapIframe.style.display = "block";
    if (mapPh) mapPh.style.display = "none";
  }

  const dirBtn = $("directionBtn");
  if (dirBtn) {
    dirBtn.href = cfg.venue.googleMapsSearchUrl || "#";
    if (isPlaceholder(cfg.venue.googleMapsSearchUrl)) {
      dirBtn.classList.add("ph");
      dirBtn.title = "⚠️ Fill in venue.googleMapsSearchUrl in js/config.js";
    }
  }

  // WhatsApp buttons
  makeWaBtn("waGroomBtn", cfg.groom.whatsapp, cfg.groom.firstName, cfg.groom.phoneDisplay);
  makeWaBtn("waBrideBtn", cfg.bride.whatsapp,  cfg.bride.firstName,  cfg.bride.phoneDisplay);
}

function makeWaBtn(id, phone, name, display) {
  const btn = $(id); if (!btn) return;
  if (!isPlaceholder(phone)) {
    const msg = encodeURIComponent(`Hi ${name}! I received your wedding invitation 💍`);
    btn.href = `https://wa.me/${phone}?text=${msg}`;
  } else {
    btn.href = "#";
    btn.classList.add("ph");
    btn.title = "⚠️ Add WhatsApp number in js/config.js";
  }
  btn.innerHTML = `<i class="fab fa-whatsapp"></i> WhatsApp ${name} (${display})`;
}

/* ─────────────────────────────────────────
   3. COUNTDOWN TIMER
───────────────────────────────────────── */
function initCountdown(iso) {
  const target = new Date(iso).getTime();
  if (isNaN(target)) return; // placeholder date — show dashes

  const update = () => {
    const diff = target - Date.now();
    if (diff <= 0) {
      ["countDays","countHours","countMins","countSecs"].forEach(id => tx(id, "00"));
      return;
    }
    const d = Math.floor(diff / 86400000);
    const h = Math.floor((diff % 86400000) / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    tx("countDays",  String(d).padStart(2,"0"));
    tx("countHours", String(h).padStart(2,"0"));
    tx("countMins",  String(m).padStart(2,"0"));
    tx("countSecs",  String(s).padStart(2,"0"));
  };
  update(); setInterval(update, 1000);
}

/* ─────────────────────────────────────────
   4. CALENDAR (.ICS + GOOGLE)
───────────────────────────────────────── */
function setupCalendar(cfg) {
  const iso   = cfg.event.dateISO;
  const start = new Date(iso);
  const valid = !isNaN(start.getTime());
  const end   = valid ? new Date(start.getTime() + 6 * 3600000) : null;
  const fmt   = d => d.toISOString().replace(/[-:]/g,"").replace(/\.\d{3}/,"");
  const dtS   = valid ? fmt(start) : "";
  const dtE   = valid ? fmt(end)   : "";

  const title    = cfg.event.calendarSummary;
  const desc     = cfg.event.calendarDescription;
  const location = cfg.venue.fullAddress;

  const icsBtn = $("icsCalBtn");
  if (icsBtn) {
    icsBtn.addEventListener("click", e => {
      e.preventDefault();
      if (!valid || isPlaceholder(iso)) {
        alert("Please fill in the event date in js/config.js first."); return;
      }
      const ics = [
        "BEGIN:VCALENDAR","VERSION:2.0",
        "PRODID:-//YomaliHarindu//WeddingInvite//EN",
        "BEGIN:VEVENT",
        `SUMMARY:${title}`,`DESCRIPTION:${desc}`,
        `LOCATION:${location}`,`DTSTART:${dtS}`,`DTEND:${dtE}`,
        "STATUS:CONFIRMED","END:VEVENT","END:VCALENDAR"
      ].join("\r\n");
      const a = Object.assign(document.createElement("a"), {
        href: URL.createObjectURL(new Blob([ics],{type:"text/calendar"})),
        download: "Yomali_Harindu_Wedding.ics"
      });
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
    });
  }

  const gcalBtn = $("gcalBtn");
  if (gcalBtn && valid) {
    gcalBtn.href = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(title)}&dates=${dtS}/${dtE}&details=${encodeURIComponent(desc)}&location=${encodeURIComponent(location)}`;
  }
}

/* ─────────────────────────────────────────
   5. TIMELINE / ORDER OF EVENTS
───────────────────────────────────────── */
function renderTimeline(schedule) {
  const container = $("timelineContainer");
  if (!container || !schedule) return;
  container.innerHTML = schedule.map(item => `
    <div class="tl-item">
      <div class="tl-node"><i class="fas ${item.icon || "fa-heart"}"></i></div>
      <div class="tl-card">
        <div class="tl-time${isPlaceholder(item.time) ? " ph" : ""}">${esc(item.time)}</div>
        <h4 class="tl-title">${esc(item.title)}</h4>
        <p class="tl-desc">${esc(item.desc)}</p>
      </div>
    </div>
  `).join("");
}

/* ─────────────────────────────────────────
   6. PHOTO GALLERY
───────────────────────────────────────── */
function renderGallery(gallery) {
  const grid = $("galleryGrid");
  if (!grid || !gallery) return;
  grid.innerHTML = gallery.map(photo => {
    const real = photo.url && !photo.url.includes("placeholder");
    return real
      ? `<div class="gallery-item" onclick="openLightbox('${esc(photo.url)}')">
           <img src="${esc(photo.url)}" alt="${esc(photo.caption)}" loading="lazy">
           <div class="gallery-caption"><p>${esc(photo.caption)}</p></div>
         </div>`
      : `<div class="gallery-item">
           <div class="gallery-ph">
             <i class="far fa-image"></i>
             <span>${esc(photo.caption)}</span>
           </div>
         </div>`;
  }).join("");
}

/* ─────────────────────────────────────────
   7. CARD SECTION
───────────────────────────────────────── */
function setupCard(cardSrc) {
  const ph     = $("cardPlaceholder");
  const wrap   = $("cardImgWrap");
  const img    = $("invitationCardImg");
  const viewBtn = $("viewCardBtn");
  const dlBtn  = $("downloadCardBtn");

  const real = cardSrc && !cardSrc.includes("placeholder")
               && cardSrc !== "assets/images/invitation-card.jpg";

  if (real) {
    if (ph)   ph.style.display   = "none";
    if (wrap) wrap.style.display = "block";
    if (img)  img.src = cardSrc;
    if (viewBtn) viewBtn.addEventListener("click", () => openLightbox(cardSrc));
    if (wrap)    wrap.addEventListener("click",    () => openLightbox(cardSrc));
    if (dlBtn)   { dlBtn.href = cardSrc; dlBtn.setAttribute("download","Yomali_Harindu_Invitation.jpg"); }
  }
  // If not real, placeholder div stays visible
}

/* ─────────────────────────────────────────
   8. LIGHTBOX
───────────────────────────────────────── */
window.openLightbox = function(src) {
  const lb = $("lightbox");
  if (lb) { $("lbImg").src = src; lb.classList.add("on"); }
};
window.closeLightbox = function() {
  const lb = $("lightbox"); if (lb) lb.classList.remove("on");
};
// Click backdrop to close
document.addEventListener("click", e => {
  const lb = $("lightbox");
  if (lb && e.target === lb) lb.classList.remove("on");
});

/* ─────────────────────────────────────────
   9. RSVP
───────────────────────────────────────── */
function setupRSVP(cfg) {
  const form = $("rsvpForm"); if (!form) return;

  form.addEventListener("submit", e => {
    e.preventDefault();
    const name       = $("rsvpName").value.trim();
    const attendance = $("rsvpAttendance").value;
    const guests     = $("rsvpGuests").value;
    const dietary    = $("rsvpDietary").value;
    const message    = $("rsvpMessage").value.trim();

    if (!name) { alert("Please enter your name."); return; }

    if (message) saveBlessing(name, message);

    // PHP backend (optional)
    fetch("api/rsvp.php", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({name, attendance, guests, dietary, message})
    }).catch(() => {});

    // WhatsApp pre-filled message
    const statusText = attendance === "attending" ? "JOYFULLY ACCEPT ✓" : "REGRETFULLY DECLINE";
    const waMsg = `*Wedding RSVP — Yomali & Harindu* 💍\n\n*Name:* ${name}\n*Status:* ${statusText}\n*Guests:* ${guests}\n*Dietary:* ${dietary}${message ? `\n*Message:* "${message}"` : ""}\n\n_Sent via the wedding website_ 🌸`;

    const phone = !isPlaceholder(cfg.groom.whatsapp) ? cfg.groom.whatsapp : "";
    const ok = confirm(`Thank you, ${name}! 🌸\n\nWould you like to send your RSVP via WhatsApp to Harindu?`);
    if (ok && phone) window.open(`https://wa.me/${phone}?text=${encodeURIComponent(waMsg)}`, "_blank");

    form.reset();
    const btn = $("rsvpSubmitBtn");
    if (btn) {
      btn.textContent = "✓ RSVP Confirmed — Thank You!";
      btn.style.background = "#25d366"; btn.style.color = "#fff";
      setTimeout(() => {
        btn.textContent = "CONFIRM MY RSVP";
        btn.style.background = ""; btn.style.color = "";
      }, 5000);
    }
  });
}

/* ─────────────────────────────────────────
   10. BLESSINGS WALL
───────────────────────────────────────── */
const SEED_BLESSINGS = [
  { name: "Family & Friends",      message: "Wishing Yomali & Harindu a lifetime filled with love, laughter, and beautiful moments together! 💕" },
  { name: "With Love",             message: "May your marriage be as beautiful as the love you share. Heartfelt congratulations to the lovely couple! 🌸" },
  { name: "A Special Blessing",    message: "Two hearts, one beautiful journey. Wishing you both every happiness on your special day and always! 💍" }
];

function setupBlessings() {
  renderBlessings();
  const form = $("blessingForm");
  if (form) {
    form.addEventListener("submit", e => {
      e.preventDefault();
      const name = $("blessingAuthor").value.trim();
      const msg  = $("blessingContent").value.trim();
      if (!name || !msg) return;
      saveBlessing(name, msg); form.reset();
    });
  }
}

function loadBlessings() {
  try {
    const raw = localStorage.getItem("blessings_yh2");
    return raw ? JSON.parse(raw) : SEED_BLESSINGS;
  } catch(e) { return SEED_BLESSINGS; }
}

function saveBlessing(name, message) {
  const list = loadBlessings();
  list.unshift({name, message});
  try { localStorage.setItem("blessings_yh2", JSON.stringify(list)); } catch(e){}
  renderBlessings();
}

function renderBlessings() {
  const grid = $("blessingsGrid"); if (!grid) return;
  grid.innerHTML = loadBlessings().slice(0, 6).map(b => `
    <div class="blessing-card">
      <p class="blessing-text">"${esc(b.message)}"</p>
      <div class="blessing-author">— ${esc(b.name)}</div>
    </div>
  `).join("");
}

/* ─────────────────────────────────────────
   11. BACKGROUND MUSIC (Web Audio + MP3 fallback)
───────────────────────────────────────── */
function setupMusic(music) {
  if (!music || !music.enabled) return;

  let playing  = false;
  let ctx      = null;
  let loopId   = null;
  let useAudio = true;

  const audioEl = new Audio(music.audioSrc || "assets/audio/wedding-bgm.mp3");
  audioEl.loop = true; audioEl.volume = 0.42;
  audioEl.addEventListener("error", () => { useAudio = false; });

  const toggle = $("musicToggleBtn");
  const bars   = document.querySelectorAll(".sbar");

  function updateUI() {
    if (!toggle) return;
    toggle.title = playing ? "Pause Music" : "Play Music";
    bars.forEach(b => playing ? b.classList.add("on") : b.classList.remove("on"));
  }

  function startSynth() {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    if (!ctx) ctx = new AC();
    if (ctx.state === "suspended") ctx.resume();
    playing = true; updateUI();

    // D major romantic chord arpeggios
    const chords = [
      [293.66, 369.99, 440.00], // D maj
      [220.00, 277.18, 329.63], // A maj
      [246.94, 293.66, 369.99], // B min
      [196.00, 246.94, 329.63], // G maj
    ];
    let ci = 0, ni = 0;

    const tick = () => {
      if (!playing) return;
      const chord = chords[ci];
      const freq  = chord[ni % chord.length];
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filt = ctx.createBiquadFilter();
      filt.type = "lowpass"; filt.frequency.value = 1200;
      osc.type = "sine"; osc.frequency.value = freq;
      const now = ctx.currentTime;
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.065, now + 0.1);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 2.0);
      osc.connect(filt); filt.connect(gain); gain.connect(ctx.destination);
      osc.start(now); osc.stop(now + 2.1);
      ni++;
      if (ni >= chord.length * 2) { ni = 0; ci = (ci + 1) % chords.length; }
      loopId = setTimeout(tick, ni % 2 === 0 ? 600 : 800);
    };
    tick();
  }

  function start() {
    if (playing) return;
    if (useAudio) {
      audioEl.play()
        .then(() => { playing = true; updateUI(); })
        .catch(() => { useAudio = false; startSynth(); });
    } else {
      startSynth();
    }
  }

  function stop() {
    playing = false;
    audioEl.pause();
    if (loopId) { clearTimeout(loopId); loopId = null; }
    updateUI();
  }

  if (toggle) toggle.addEventListener("click", () => playing ? stop() : start());
  window._music = { start, stop };
}
