/**
 * Wedding Invitation Website Configuration
 * -------------------------------------------------------------
 * Edit this file to customize all details, names, dates, times,
 * venue information, phone numbers, and images for the wedding!
 */

const WEDDING_CONFIG = {
  // Couple Information
  bride: {
    firstName: "Yashodya",
    fullName: "Yashodya Wickramaratne",
    parents: "Mr. and Mrs. Wickramaratne",
    phone: "0717172900",
    phoneDisplay: "071 717 2900",
    whatsapp: "94717172900",
    instagram: "",
    bio: "The bride who brings warmth, grace, and joy to every moment."
  },
  groom: {
    firstName: "Vihanga",
    fullName: "Vihanga Aluthge",
    parents: "Mr. and Mrs. Aluthge",
    phone: "0779140659",
    phoneDisplay: "077 914 0659",
    whatsapp: "94779140659",
    instagram: "",
    bio: "The groom who found his forever partner and home in her smile."
  },

  // Event Date & Time (Sri Lanka Standard Time: GMT+05:30)
  event: {
    // ISO format string for countdown: YYYY-MM-DDTHH:mm:ss+05:30
    dateISO: "2026-12-14T10:00:00+05:30",
    dayOfWeek: "Monday",
    dateFormatted: "14th December 2026",
    startTime: "10:00 AM",
    poruwaTime: "10:50 AM",
    rsvpDeadline: "30th November 2026",
    calendarSummary: "Wedding of Yashodya & Vihanga",
    calendarDescription: "We warmly invite you to celebrate our wedding at Deandra Bolgoda. Poruwa ceremony begins at 10:50 AM.",
  },

  // Venue Information
  venue: {
    name: "Deandra Bolgoda",
    subName: "Bolgoda Lake, Sri Lanka",
    fullAddress: "Deandra Bolgoda, Bolgoda Lake, Piliyandala / Moratuwa, Sri Lanka",
    googleMapsSearchUrl: "https://www.google.com/maps/search/?api=1&query=Deandra+Bolgoda",
    // Embed map URL for iframe
    googleMapsEmbedUrl: "https://maps.google.com/maps?q=Deandra%20Bolgoda&t=&z=15&ie=UTF8&iwloc=&output=embed",
    dressCode: "Formal / Traditional Sri Lankan / Elegant Pastel & Gold",
    parkingInfo: "Ample on-site parking available with valet assistance."
  },

  // Schedule / Order of Events
  schedule: [
    {
      time: "10:00 AM",
      title: "Welcome & Arrival",
      desc: "Gathering of family and friends with welcome refreshments by Bolgoda Lake.",
      icon: "fa-glass-cheers"
    },
    {
      time: "10:50 AM",
      title: "Traditional Poruwa Ceremony",
      desc: "The sacred traditional Sri Lankan rituals and tying of the wedding knot at the auspicious time.",
      icon: "fa-ring"
    },
    {
      time: "11:45 AM",
      title: "Champagne Toast & Cake Cutting",
      desc: "Celebratory toast, lighting of the traditional oil lamp, and cake cutting.",
      icon: "fa-cake-candles"
    },
    {
      time: "12:30 PM",
      title: "Wedding Lunch & Banquet",
      desc: "A delectable culinary feast and celebration with live music.",
      icon: "fa-utensils"
    },
    {
      time: "02:00 PM",
      title: "Music, Celebration & Photos",
      desc: "Music, dancing, laughter, and family photographs.",
      icon: "fa-music"
    },
    {
      time: "03:30 PM",
      title: "Going Away & Farewell",
      desc: "Blessings and warm wishes as the newly wedded couple departs.",
      icon: "fa-car-side"
    }
  ],

  // Gallery Photos (Placeholders that can be replaced with real photos)
  gallery: [
    {
      url: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=800&q=80",
      caption: "Together is our favorite place to be",
      category: "Engagement"
    },
    {
      url: "https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=800&q=80",
      caption: "Hand in hand towards forever",
      category: "Our Journey"
    },
    {
      url: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=800&q=80",
      caption: "Every love story is beautiful, but ours is our favorite",
      category: "Moments"
    },
    {
      url: "https://images.unsplash.com/photo-1606800052052-a08af7148866?auto=format&fit=crop&w=800&q=80",
      caption: "Two hearts, one lifelong promise",
      category: "Love"
    }
  ],

  // Physical Invitation Card Image
  invitationCardImage: "assets/images/invitation-card.jpg",

  // Audio / Music Settings
  music: {
    enabled: true,
    autoplayOnOpen: true, // will play when envelope is opened
    trackTitle: "Romantic Wedding Melody",
    audioSrc: "assets/audio/romantic-bgm.mp3" // Optional custom MP3; if missing, falls back to Web Audio romantic acoustic chords
  }
};

// Export to window
if (typeof window !== "undefined") {
  window.WEDDING_CONFIG = WEDDING_CONFIG;
}
