/**
 * Yashodya & Vihanga Wedding Invitation - Main Application Logic
 */

document.addEventListener("DOMContentLoaded", () => {
  const config = window.WEDDING_CONFIG;
  if (!config) {
    console.error("WEDDING_CONFIG is missing!");
    return;
  }

  // 1. Hydrate Static Content from Config
  hydrateContent(config);

  // 2. Initialize Countdown Timer
  initCountdown(config.event.dateISO);

  // 3. Setup Calendar (.ics & Google Calendar)
  setupCalendar(config);

  // 4. Setup Schedule Timeline
  renderSchedule(config.schedule);

  // 5. Setup Gallery
  renderGallery(config.gallery);

  // 6. Setup Card Lightbox & Download
  setupCardModal(config.invitationCardImage);

  // 7. Setup RSVP Form & WhatsApp Handlers
  setupRSVP(config);

  // 8. Setup Blessings Wall
  setupBlessingsWall();
});

/**
 * Hydrates elements with IDs or data attributes
 */
function hydrateContent(cfg) {
  // Couple names & Parents
  setText("brideFirstName", cfg.bride.firstName);
  setText("groomFirstName", cfg.groom.firstName);
  setText("heroBrideName", cfg.bride.firstName);
  setText("heroGroomName", cfg.groom.firstName);
  setText("brideParents", cfg.bride.parents);
  setText("groomParents", cfg.groom.parents);

  // Date & Time
  setText("eventDayOfWeek", cfg.event.dayOfWeek);
  setText("eventDateFormatted", cfg.event.dateFormatted);
  setText("eventStartTime", `${cfg.event.startTime} Onwards`);
  setText("poruwaCeremonyTime", `Poruwa Ceremony ${cfg.event.poruwaTime}`);
  setText("rsvpDeadlineDate", cfg.event.rsvpDeadline);

  // Venue
  setText("venueTitle", cfg.venue.name);
  setText("venueSubTitle", cfg.venue.subName);
  setText("venueAddress", cfg.venue.fullAddress);
  setText("venueDressCode", cfg.venue.dressCode);
  setText("venueParking", cfg.venue.parkingInfo);

  // Maps Link
  const mapBtn = document.getElementById("openMapsBtn");
  if (mapBtn) {
    mapBtn.href = cfg.venue.googleMapsSearchUrl;
  }

  const mapIframe = document.getElementById("venueMapIframe");
  if (mapIframe && cfg.venue.googleMapsEmbedUrl) {
    mapIframe.src = cfg.venue.googleMapsEmbedUrl;
  }

  // WhatsApp Buttons
  const groomWaBtn = document.getElementById("groomWhatsAppBtn");
  if (groomWaBtn) {
    groomWaBtn.href = `https://wa.me/${cfg.groom.whatsapp}?text=${encodeURIComponent(`Hi ${cfg.groom.firstName}, I received your wedding invitation!`)}`;
    groomWaBtn.innerHTML = `<i class="fab fa-whatsapp"></i> WhatsApp ${cfg.groom.firstName} (${cfg.groom.phoneDisplay})`;
  }

  const brideWaBtn = document.getElementById("brideWhatsAppBtn");
  if (brideWaBtn) {
    brideWaBtn.href = `https://wa.me/${cfg.bride.whatsapp}?text=${encodeURIComponent(`Hi ${cfg.bride.firstName}, I received your wedding invitation!`)}`;
    brideWaBtn.innerHTML = `<i class="fab fa-whatsapp"></i> WhatsApp ${cfg.bride.firstName} (${cfg.bride.phoneDisplay})`;
  }

  // Invitation card image
  const cardImg = document.getElementById("invitationCardImg");
  if (cardImg) {
    cardImg.src = cfg.invitationCardImage;
  }
}

function setText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

/**
 * Live Countdown Timer
 */
function initCountdown(targetISO) {
  const targetDate = new Date(targetISO).getTime();

  const daysEl = document.getElementById("countDays");
  const hoursEl = document.getElementById("countHours");
  const minsEl = document.getElementById("countMins");
  const secsEl = document.getElementById("countSecs");

  function update() {
    const now = new Date().getTime();
    const distance = targetDate - now;

    if (distance <= 0) {
      if (daysEl) daysEl.textContent = "00";
      if (hoursEl) hoursEl.textContent = "00";
      if (minsEl) minsEl.textContent = "00";
      if (secsEl) secsEl.textContent = "00";
      return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const mins = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const secs = Math.floor((distance % (1000 * 60)) / 1000);

    if (daysEl) daysEl.textContent = String(days).padStart(2, "0");
    if (hoursEl) hoursEl.textContent = String(hours).padStart(2, "0");
    if (minsEl) minsEl.textContent = String(mins).padStart(2, "0");
    if (secsEl) secsEl.textContent = String(secs).padStart(2, "0");
  }

  update();
  setInterval(update, 1000);
}

/**
 * Calendar Event (.ics & Google Calendar)
 */
function setupCalendar(cfg) {
  const calBtn = document.getElementById("addToCalendarBtn");
  const gcalBtn = document.getElementById("googleCalendarBtn");

  // Format date for iCal (20261214T043000Z in UTC -> 10:00 AM SLST is 04:30 AM UTC)
  // Wedding start: 2026-12-14 10:00 SLST (04:30 UTC), End: 16:00 SLST (10:30 UTC)
  const dtStart = "20261214T043000Z";
  const dtEnd = "20261214T103000Z";
  const title = cfg.event.calendarSummary;
  const description = `${cfg.event.calendarDescription}\\n\\nVenue: ${cfg.venue.fullAddress}`;
  const location = cfg.venue.fullAddress;

  if (calBtn) {
    calBtn.addEventListener("click", (e) => {
      e.preventDefault();

      const icsData = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//YomaliHarindu//WeddingInvite//EN",
        "CALSCALE:GREGORIAN",
        "BEGIN:VEVENT",
        `SUMMARY:${title}`,
        `DESCRIPTION:${description}`,
        `LOCATION:${location}`,
        `DTSTART:${dtStart}`,
        `DTEND:${dtEnd}`,
        "STATUS:CONFIRMED",
        "END:VEVENT",
        "END:VCALENDAR"
      ].join("\r\n");

      const blob = new Blob([icsData], { type: "text/calendar;charset=utf-8" });
      const link = document.createElement("a");
      link.href = window.URL.createObjectURL(blob);
      link.setAttribute("download", "Yashodya_Vihanga_Wedding.ics");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    });
  }

  if (gcalBtn) {
    const gcalUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(title)}&dates=${dtStart}/${dtEnd}&details=${encodeURIComponent(description)}&location=${encodeURIComponent(location)}`;
    gcalBtn.href = gcalUrl;
  }
}

/**
 * Render Schedule Timeline
 */
function renderSchedule(scheduleList) {
  const container = document.getElementById("scheduleTimelineContainer");
  if (!container || !scheduleList) return;

  container.innerHTML = scheduleList
    .map(
      (item) => `
    <div class="timeline-item">
      <div class="timeline-icon-node">
        <i class="fas ${item.icon || 'fa-heart'}"></i>
      </div>
      <div class="timeline-content">
        <div class="timeline-time">${item.time}</div>
        <h4 class="timeline-title">${item.title}</h4>
        <p class="timeline-desc">${item.desc}</p>
      </div>
    </div>
  `
    )
    .join("");
}

/**
 * Render Gallery Photos
 */
function renderGallery(galleryList) {
  const container = document.getElementById("galleryGridContainer");
  if (!container || !galleryList) return;

  container.innerHTML = galleryList
    .map(
      (photo) => `
    <div class="gallery-item" onclick="openLightbox('${photo.url}', '${escapeHtml(photo.caption)}')">
      <img src="${photo.url}" alt="${escapeHtml(photo.caption)}" loading="lazy">
      <div class="gallery-caption">
        <p>${photo.caption}</p>
      </div>
    </div>
  `
    )
    .join("");
}

/**
 * Physical Card Lightbox Modal & Download
 */
function setupCardModal(cardImgSrc) {
  const viewCardBtn = document.getElementById("viewCardBtn");
  const downloadCardBtn = document.getElementById("downloadCardBtn");
  const cardImg = document.getElementById("invitationCardImg");

  if (viewCardBtn) {
    viewCardBtn.addEventListener("click", () => {
      openLightbox(cardImgSrc, "Yashodya & Vihanga Wedding Invitation Card");
    });
  }

  if (cardImg) {
    cardImg.addEventListener("click", () => {
      openLightbox(cardImgSrc, "Yashodya & Vihanga Wedding Invitation Card");
    });
  }

  if (downloadCardBtn) {
    downloadCardBtn.href = cardImgSrc;
    downloadCardBtn.setAttribute("download", "Yashodya_Vihanga_Wedding_Invitation.jpg");
  }
}

/**
 * Lightbox Modal
 */
window.openLightbox = function (imgSrc, title = "") {
  let modal = document.getElementById("globalLightboxModal");
  if (!modal) {
    modal = document.createElement("div");
    modal.id = "globalLightboxModal";
    modal.className = "modal-backdrop";
    modal.innerHTML = `
      <button class="modal-close-btn" onclick="closeLightbox()">&times;</button>
      <img id="lightboxImg" class="modal-content-img" src="" alt="Preview">
    `;
    document.body.appendChild(modal);

    modal.addEventListener("click", (e) => {
      if (e.target === modal) closeLightbox();
    });
  }

  const img = modal.querySelector("#lightboxImg");
  img.src = imgSrc;
  modal.classList.add("active");
};

window.closeLightbox = function () {
  const modal = document.getElementById("globalLightboxModal");
  if (modal) modal.classList.remove("active");
};

/**
 * RSVP Form & WhatsApp Submissions
 */
function setupRSVP(cfg) {
  const form = document.getElementById("rsvpForm");
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const name = document.getElementById("rsvpName").value.trim();
    const attendance = document.getElementById("rsvpAttendance").value;
    const guests = document.getElementById("rsvpGuests").value;
    const dietary = document.getElementById("rsvpDietary").value;
    const message = document.getElementById("rsvpMessage").value.trim();

    if (!name) {
      alert("Please enter your name.");
      return;
    }

    // Save blessing to blessings wall if message provided
    if (message) {
      saveBlessing(name, message);
    }

    // Try posting to local PHP backend if available
    try {
      fetch("api/rsvp.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, attendance, guests, dietary, message })
      }).catch(() => {});
    } catch (e) {}

    // Construct WhatsApp confirmation text
    const statusText = attendance === "attending" ? "JOYFULLY ACCEPT" : "REGRETFULLY DECLINE";
    const waText = `*Wedding RSVP for Yashodya & Vihanga*\n\n` +
      `*Guest Name:* ${name}\n` +
      `*Status:* ${statusText}\n` +
      `*Attending Guests:* ${guests}\n` +
      `*Dietary:* ${dietary}\n` +
      (message ? `*Wishes:* "${message}"\n` : "") +
      `\n_Sent via Wedding Website_`;

    // Choose phone number to send to (default Groom Vihanga or Bride Yashodya)
    const targetPhone = cfg.groom.whatsapp;
    const waUrl = `https://wa.me/${targetPhone}?text=${encodeURIComponent(waText)}`;

    // Show nice confirmation modal or prompt
    const confirmWhatsApp = confirm(
      `Thank you, ${name}! Your RSVP has been recorded.\n\nWould you like to send this confirmation directly to Vihanga on WhatsApp?`
    );

    if (confirmWhatsApp) {
      window.open(waUrl, "_blank");
    }

    // Reset form or mark submitted
    form.reset();
    const submitBtn = document.getElementById("rsvpSubmitBtn");
    if (submitBtn) {
      submitBtn.textContent = "✓ RSVP Submitted - Thank You!";
      submitBtn.style.background = "#25d366";
      submitBtn.style.color = "#fff";
      setTimeout(() => {
        submitBtn.textContent = "Submit RSVP";
        submitBtn.style.background = "";
        submitBtn.style.color = "";
      }, 5000);
    }
  });
}

/**
 * Blessings Wall & LocalStorage
 */
const INITIAL_BLESSINGS = [
  {
    name: "Kasun & Sandani",
    message: "Wishing you both a lifetime of love, laughter, and endless happiness! Cannot wait to celebrate with you at Bolgoda!"
  },
  {
    name: "Nuwan Wickramaratne",
    message: "Congratulations Yashodya and Vihanga! May your journey together be blessed with joy, peace, and abundance."
  },
  {
    name: "Devinda Aluthge",
    message: "Heartiest congratulations to the wonderful couple. Looking forward to the big day on the 14th!"
  }
];

function setupBlessingsWall() {
  renderBlessings();

  const directBlessingForm = document.getElementById("directBlessingForm");
  if (directBlessingForm) {
    directBlessingForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const name = document.getElementById("blessingAuthor").value.trim();
      const msg = document.getElementById("blessingContent").value.trim();
      if (!name || !msg) return;

      saveBlessing(name, msg);
      directBlessingForm.reset();
      renderBlessings();
    });
  }
}

function getSavedBlessings() {
  try {
    const raw = localStorage.getItem("wedding_blessings_yv");
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {}
  return INITIAL_BLESSINGS;
}

function saveBlessing(name, message) {
  const blessings = getSavedBlessings();
  blessings.unshift({ name, message });
  try {
    localStorage.setItem("wedding_blessings_yv", JSON.stringify(blessings));
  } catch (e) {}
  renderBlessings();
}

function renderBlessings() {
  const grid = document.getElementById("blessingsWallGrid");
  if (!grid) return;

  const blessings = getSavedBlessings();
  grid.innerHTML = blessings
    .slice(0, 6)
    .map(
      (b) => `
    <div class="blessing-card">
      <p class="blessing-card-text">"${escapeHtml(b.message)}"</p>
      <div class="blessing-card-author">- ${escapeHtml(b.name)}</div>
    </div>
  `
    )
    .join("");
}

function escapeHtml(text) {
  if (!text) return "";
  const map = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  };
  return text.replace(/[&<>"']/g, (m) => map[m]);
}
